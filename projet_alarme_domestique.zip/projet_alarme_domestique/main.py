from database import (DB_PATH, init_db,select_sql, insert_sql, delete_sql)


if __name__ == "__main__":
    init_db()
