from flask import Flask, render_template, request, redirect, url_for, Response
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
from database import init_db, select_sql, insert_sql
import csv
import io

app = Flask(__name__)

def bool_alarme_activee()->bool:
    """
    Retourne True si l'alarme est activée False sinon
    """
    lignes = select_sql("SELECT est_activee FROM etat_alarme WHERE id = 1", ())
    if not lignes:
        return False
    return bool(lignes[0][0])


def alarme_activee(est_activee: bool):
    """
    Met à jour l'état de l'alarme
    """
    insert_sql("UPDATE etat_alarme SET est_activee = ?, mise_a_jour_le = CURRENT_TIMESTAMP WHERE id = 1", (1 if est_activee else 0,))

def ajouter_evenement_historique(type_evenement: str, etat: str, description: str = ""):
    insert_sql("INSERT INTO historique_alarme (type_evenement, etat, description) VALUES (?, ?, ?)", (type_evenement, etat, description))

def types_disponibles() -> list[str]:
    """
    Récupère la liste des types d'événements présents dans l'historique

    Retourne: list[str]: Liste des types d'événements
    Sinon retourne une liste vide
    """
    lignes = select_sql("SELECT DISTINCT type_evenement FROM historique_alarme ORDER BY type_evenement", ())
    return [ligne[0] for ligne in lignes]

def recuperer_historique(periode: str, type_filtre: str, etat_filtre: str):
    """
    Retourne les événements selon les filtres sélectionnés
    """
    conditions = []
    parametres = []

    # Période
    now = datetime.now()
    debut = None
    if periode == "aujourdhui":
        debut = datetime(now.year, now.month, now.day)
    elif periode == "7j":
        debut = now - timedelta(days=7)
    elif periode == "30j":
        debut = now - timedelta(days=30)

    if debut is not None:
        conditions.append("date_heure >= ?")
        parametres.append(debut.strftime("%Y-%m-%d %H:%M:%S"))

    # Type
    if type_filtre and type_filtre != "tous":
        conditions.append("type_evenement = ?")
        parametres.append(type_filtre)

    # État
    if etat_filtre and etat_filtre != "tous":
        conditions.append("etat = ?")
        parametres.append(etat_filtre)

    where_sql = ("WHERE " + " AND ".join(conditions)) if conditions else ""

    lignes = select_sql(f"SELECT id, date_heure, type_evenement, etat, description FROM historique_alarme {where_sql} ORDER BY date_heure DESC", tuple(parametres),)
    
    # Mise en forme affichage
    today = datetime.now().date()
    evenements = []
    for (id_evenement, date_heure, type_evenement, etat, description) in lignes:
        try:
            dt = datetime.fromisoformat(str(date_heure))
        except ValueError:
            dt = datetime.strptime(str(date_heure), "%Y-%m-%d %H:%M:%S")

        if dt.date() == today:
            date_affichee = dt.strftime("%H:%M")
        else:
            date_affichee = dt.strftime("%d/%m %H:%M")

        evenements.append(
            {
                "id": id_evenement,
                "date_affichee": date_affichee,
                "date_heure": dt.strftime("%Y-%m-%d %H:%M:%S"),
                "type": type_evenement,
                "etat": etat,
                "description": description or "",
            }
        )

    return evenements

@app.before_request
def setup_db():
    """
    Initialise la base et crée un compte de test 'demo'
    seulement s'il n'existe pas déjà
    """
    init_db()

    lignes = select_sql("SELECT COUNT(*) FROM users WHERE username = ?", ("demo",))
    nb_demo = lignes[0][0]

    if nb_demo == 0:
        mdp_hache = generate_password_hash("1234")  # mot de passe haché
        insert_sql("INSERT INTO users (username, password_hash, email) VALUES (?, ?, ?)", ("demo", mdp_hache, "demo@example.com"))


@app.route("/", methods=["GET", "POST"])
def login():
    """
    Page de connexion :
    - Si identifiants corrects -> redirection vers /index
    - Sinon -> message "Nom d'utilisateur ou mot de passe incorrecte"
    """
    message = None
    erreur = None

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        if not username or not password:
            erreur = "Merci de remplir les deux champs."
        else:
            # Chercher l'utilisateur dans la base
            lignes = select_sql("SELECT id, password_hash FROM users WHERE username = ?", (username,))

            if not lignes:
                # Utilisateur non trouvé
                erreur = "Nom d'utilisateur ou mot de passe incorrecte."
            else:
                user_id, mdp_stocke = lignes[0]

                # Vérification du mot de passe haché
                if check_password_hash(mdp_stocke, password):
                    return redirect(url_for("home"))
                else:
                    erreur = "Nom d'utilisateur ou mot de passe incorrecte."

    return render_template("login.html", message=message, erreur=erreur)


@app.route("/register", methods=["GET", "POST"])
def register():
    """
    Page de création de compte :
    - username
    - mot de passe haché
    - email
    """
    erreur = None
    message = None

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password1 = request.form.get("password1", "").strip()
        password2 = request.form.get("password2", "").strip()
        email = request.form.get("email", "").strip()

        # Vérifications simples
        if not username or not password1 or not password2 or not email:
            erreur = "Merci de remplir tous les champs."
        elif password1 != password2:
            erreur = "Les deux mots de passe ne correspondent pas."
        else:
            # Vérifier si le nom d'utilisateur existe déjà
            user_existant = select_sql("SELECT id FROM users WHERE username = ?", (username,))

            if user_existant:
                erreur = "Ce nom d'utilisateur existe déjà. Choisis-en un autre."
            else:
                #  Hasher le mot de passe avant de le stocker
                mdp_hache = generate_password_hash(password1)
                insert_sql("INSERT INTO users (username, password_hash, email) VALUES (?, ?, ?)", (username, mdp_hache, email))
                message = "Compte créé avec succès. Tu peux maintenant te connecter."

    return render_template("register.html", erreur=erreur, message=message)


@app.route("/index")
def home():
    """
    Page d'accueil après connexion
    """
    alarme_activee = bool_alarme_activee()
    return render_template("index.html", alarme_activee=alarme_activee)

@app.route("/alarm/toggle", methods=["POST"])
def toggle_alarm():
    etat_actuel = bool_alarme_activee()
    nouvel_etat = not etat_actuel
    alarme_activee(nouvel_etat)

    if nouvel_etat:
        deja_arme = select_sql("SELECT COUNT(*) FROM historique_alarme WHERE type_evenement IN ('Armement', 'Réarmement')", ())[0][0]
        type_evenement = "Réarmement" if deja_arme else "Armement"
        ajouter_evenement_historique(type_evenement, "ARMÉ")
    else:
        ajouter_evenement_historique("Désarmement", "DÉSARMÉ")

    return redirect(url_for("home"))

@app.route("/historique")
def historique_alarme():
    """
    Page Historique des événements
    """
    periode = request.args.get("periode", "aujourdhui")
    type_filtre = request.args.get("type", "tous")
    etat_filtre = request.args.get("etat", "tous")

    evenements = recuperer_historique(periode, type_filtre, etat_filtre)
    liste_types_disponibles = types_disponibles()

    return render_template("historique.html", evenements=evenements, periode=periode, type_filtre=type_filtre, etat_filtre=etat_filtre, types_disponibles=liste_types_disponibles)

@app.route("/historique/<id_evenement>")
def detail_evenement_alarme(id_evenement: int):
    """
    Page Détail d'un événement
    """
    lignes = select_sql("SELECT id, date_heure, type_evenement, etat, description FROM historique_alarme WHERE id = ?", (id_evenement,))
    if not lignes:
        return render_template("detail_evenement.html", evenement=None)

    (id_evenement, date_heure, type_evenement, etat, description) = lignes[0]
    evenement = {
        "id": id_evenement,
        "date_heure": str(date_heure),
        "type": type_evenement,
        "etat": etat,
        "description": description or "",
    }
    
    return render_template("detail_evenement.html", evenement=evenement)

@app.route("/historique/export")
def exporter_historique_alarme():
    """
    Exporte un fichier CSV de l'historique
    """
    periode = request.args.get("periode", "aujourdhui")
    type_filtre = request.args.get("type", "tous")
    etat_filtre = request.args.get("etat", "tous")

    evenements = recuperer_historique(periode, type_filtre, etat_filtre)

    sortie = io.StringIO()
    writer = csv.writer(sortie, delimiter=";", lineterminator="\n")

    for e in evenements:
        description = " ".join((e["description"] or "").splitlines())
        writer.writerow([e["date_heure"], e["type"], e["etat"], description])


    contenu_csv = sortie.getvalue()

    reponse = Response(contenu_csv.encode("utf-8-sig"))
    reponse.headers["Content-Type"] = "text/csv; charset=utf-8"
    reponse.headers["Content-Disposition"] = "attachment; filename=historique_alarme.csv"
    return reponse

if __name__ == "__main__":
    app.run(debug=True)
